--foreign 1
INSERT INTO Books (bookID, authorID, bookName, publisherID, pubDate, price, category, lastOrderDate, totalOrdered)
VALUES ('12345', 2.1, 'Hello', NULL, 01-12-1234, 45.00, F, 01-12-1234, 70);

--foreign 2
INSERT INTO Orders (memberID, bookID, orderDate, quantity)
VALUES (5.4, '12345', 01-12-1234, NULL);

--foreign 3
INSERT INTO Reviews (reviewerID, bookID, reviewDate, reviewStars)
VALUES (8.7, '12345', 01-12-1234, NULL);

--general 1
UPDATE Orders
SET quantity = 1;

UPDATE Orders 
SET quantity = -1;

--general 2
UPDATE Books
SET pubDate = '01/01/18', lastOrderDate = '01/01/18';

UPDATE Books
SET pubDate = '01/02/18', lastOrderDate = '01/01/18';

--general 3
UPDATE Members
SET joinDate = NULL, isCurrentMember = NULL;

UPDATE Members
SET joinDate = NULL, isCurrentMember = TRUE;
