SELECT b.publisherID, gp.numReviewedPublished, COUNT(BB.bookID) AS numBad
FROM GreatPublishers GP, BadBookTotals BB, Books b
WHERE b.bookID = BB.bookID
AND b.publisherID = GP.publisherID
GROUP BY b.publisherID, GP.numReviewedPublished 
HAVING COUNT(BB.bookID) >= 1;

-- publisherid | numreviewedplublished | numbad
---------------+-----------------------+--------
--        31725|                      2|      2
-- (1 row)


DELETE FROM Orders
WHERE memberID = 8844 and	
	  bookID = 'jgzhwq';

DELETE FROM Orders
WHERE memberID = 2161 and
	  bookID = 'rrrrrr';

-- publisherid | numreviewedplublished | numbad
---------------+-----------------------+--------
--        31725|                      2|      2
-- (1 row)
