CREATE VIEW GreatPublishers AS
SELECT B.publisherID, COUNT(DISTINCT R.bookID) AS numReviewedPublished
FROM Books b, Reviews r
WHERE B.bookID = R.bookID
GROUP BY B.publisherID 
HAVING COUNT(DISTINCT R.bookID) >= 2 
AND EVERY (R.reviewStars >=3);

CREATE VIEW BadBookTotals AS
SELECT B.bookID, B.totalOrdered, SUM(o.quantity) AS badQuantitySum
FROM Books B, Orders o
WHERE B.bookID = o.bookID
GROUP BY B.bookID
HAVING B.totalOrdered <> SUM(o.quantity)
UNION
SELECT B.bookID, B.totalOrdered, 0 AS badQuantitySum
FROM Books B
WHERE B.totalOrdered <> 0
AND B.bookID NOT IN (SELECT o.bookID FROM Orders o);