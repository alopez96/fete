BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;

UPDATE Members
SET memberName = n.memberName, renewalDate = n.renewalDate, isCurrentMember = TRUE
FROM NewMemberships n
WHERE Members.memberID = n.memberID;

INSERT INTO Members (memberID, memberName, joinDate, renewalDate, isCurrentMember)
SELECT memberID, memberName, CURRENT_DATE, renewalDate, TRUE
FROM NewMemberships n
WHERE NOT EXISTS(SELECT * FROM Members n WHERE m.memberID = n.memberID);

COMMIT;
